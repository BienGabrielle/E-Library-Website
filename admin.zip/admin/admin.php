<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - E-Library</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            padding: 20px; 
            background-color: #f0f0f0; 
        }
        .container {
            max-width: 900px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .form-group { 
            margin-bottom: 15px; 
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input, 
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background-color: #45a049;
        }
        .book-list {
            margin-top: 30px;
        }
        .book {
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background: white;
        }
        .books-container {
            display: none;
            margin-left: 20px;
        }
        h2 {
            cursor: pointer;
        }
        .toggle-text {
            color: #007bff;
            margin-left: 10px;
            font-size: 0.5em;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Admin Panel - E-Library</h1>

        <form id="bookForm" enctype="multipart/form-data">
            <div class="form-group">
                <label>Category:</label>
                <select name="category" required>
                    <option value="horror">Horror</option>
                    <option value="fantasy">Fantasy</option>
                    <option value="science_fiction">Science Fiction</option>
                    <option value="mystery">Mystery</option>
                    <option value="romance">Romance</option>
                    <option value="adventure">Adventure</option>
                    <option value="non_fiction">Non-Fiction</option>
                    <option value="historical">Historical</option>
                </select>
            </div>
            <div class="form-group">
                <label>Title:</label>
                <input type="text" name="title" required>
            </div>
            <div class="form-group">
                <label>Author:</label>
                <input type="text" name="author" required>
            </div>
            <div class="form-group">
                <label>Year:</label>
                <input type="number" name="year" required>
            </div>
            <div class="form-group">
                <label>Description:</label>
                <textarea name="description" rows="4" required></textarea>
            </div>
            <div class="form-group">
                <label>Upload Image:</label>
                <input type="file" name="image" accept="image/*">
            </div>
            <button type="submit">Add Book</button>
        </form>

        <div id="response"></div>
        <div class="book-list" id="bookList"></div>
    </div>
        <!-- Update Book Popup Form -->
    <!-- Update Book Popup Form -->
    <div id="updatePopup" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); z-index: 9999;">
        <div style="position: relative; margin: auto; top: 50%; transform: translateY(-50%); background: white; padding: 20px; border-radius: 8px; width: 400px;">
            <h2>Update Book</h2>
            <form id="updateForm">
                <input type="hidden" name="id" id="updateId">
                <input type="hidden" name="category" id="updateCategory">
                
                <div>
                    <label>Title:</label>
                    <input type="text" id="updateTitle" name="title" required>
                </div>
                <div>
                    <label>Author:</label>
                    <input type="text" id="updateAuthor" name="author" required>
                </div>
                <div>
                    <label>Year:</label>
                    <input type="number" id="updateYear" name="year" required>
                </div>
                <div>
                    <label>Description:</label>
                    <textarea id="updateDescription" name="description" rows="4" required></textarea>
                </div>
                <div style="margin-top: 10px;">
                    <button type="submit">Update Book</button>
                    <button type="button" onclick="closeUpdateForm()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('updateForm').addEventListener('submit', async (event) => {
        event.preventDefault();

        const formData = new FormData(event.target);

        const response = await fetch('../e-library-backend.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();
        if (result.message) {
            alert(result.message);
            closeUpdateForm();
            fetchBooks();
        }
    });
        const openUpdateForm = (category, book) => {
        document.getElementById('updatePopup').style.display = 'block';
        document.getElementById('updateId').value = book.id;
        document.getElementById('updateCategory').value = category;
        document.getElementById('updateTitle').value = book.title;
        document.getElementById('updateAuthor').value = book.author;
        document.getElementById('updateYear').value = book.year;
        document.getElementById('updateDescription').value = book.description;
    };

    const closeUpdateForm = () => {
        document.getElementById('updatePopup').style.display = 'none';
    };

    document.getElementById('updateForm').addEventListener('submit', async (event) => {
        event.preventDefault();

        const formData = new FormData(event.target);
        formData.append('action', 'update');

        const response = await fetch('../e-library-backend.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();
        if (result.message) {
            alert(result.message);
            closeUpdateForm();
            fetchBooks();
        }
    });
        const updateBook = async (category, id) => {
        const title = prompt("Enter new title:");
        const author = prompt("Enter new author:");
        const year = prompt("Enter new year:");
        const description = prompt("Enter new description:");

        if (!title || !author || !year || !description) {
            alert("All fields are required.");
            return;
        }

        const formData = new FormData();
        formData.append('action', 'update');
        formData.append('id', id);
        formData.append('title', title);
        formData.append('author', author);
        formData.append('year', year);
        formData.append('description', description);
        formData.append('category', category);

        const response = await fetch('../e-library-backend.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();
        if (result.message) {
            alert(result.message);
            fetchBooks();  // Refresh the book list after updating
        }
    };
        const deleteBook = async (category, id) => {
        if (!confirm("Are you sure you want to delete this book?")) return;

        const response = await fetch(`../e-library-backend.php?action=delete&category=${category}&id=${id}`, {
            method: 'GET'
        });

        const result = await response.json();
        if (result.message) {
            alert(result.message);
            fetchBooks();  // Refresh the book list after deletion
        }
    };
        document.getElementById('bookForm').addEventListener('submit', async (event) => {
        event.preventDefault();

        const form = event.target;
        const formData = new FormData(form);
        formData.append('action', 'create');

        const response = await fetch('../e-library-backend.php?action=create', {
        method: 'POST',
        body: formData
    });

        const result = await response.text();
        document.getElementById('response').innerHTML = result;

        form.reset();
        fetchBooks();  // Refresh book list after adding a book
    });

        const fetchBooks = async () => {
            const response = await fetch('../e-library-backend.php?action=read');
            const books = await response.json();

            const bookList = document.getElementById('bookList');
            bookList.innerHTML = '';

            for (const [category, booksArray] of Object.entries(books)) {
                const categoryDiv = document.createElement('div');

                categoryDiv.innerHTML = `<h2 onclick="toggleCategory(this)">${category.toUpperCase()} <span class="toggle-text">(Open)</span></h2>`;

                const booksContainer = document.createElement('div');
                booksContainer.className = 'books-container';

                booksArray.forEach(book => {
                    const bookDiv = document.createElement('div');
                    bookDiv.className = 'book';
                    bookDiv.innerHTML = `
                        <strong>${book.title}</strong> by ${book.author} (${book.year})<br>
                        <small>${book.description}</small><br>
                        ${book.image_path ? `<img src="../${book.image_path}" width="100" height="150"><br>` : ''}
                        <button onclick="openUpdateForm('${category}', ${JSON.stringify(book).replace(/"/g, '&quot;')})">Update</button>
                        <button onclick="deleteBook('${category}', ${book.id})">Delete</button>
                    `;
                    booksContainer.appendChild(bookDiv);
                });

                categoryDiv.appendChild(booksContainer);
                bookList.appendChild(categoryDiv);
            }
        }

        const toggleCategory = (heading) => {
            const booksContainer = heading.nextElementSibling;
            const toggleText = heading.querySelector('.toggle-text');
            if (booksContainer.style.display === 'none' || booksContainer.style.display === '') {
                booksContainer.style.display = 'block';
                toggleText.textContent = '(Close)';
            } else {
                booksContainer.style.display = 'none';
                toggleText.textContent = '(Open)';
            }
        }

        fetchBooks();
    </script>
</body>
</html>
