<?php

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'dweb_database';

// Connect to the database
$conn = new mysqli($host, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category = $_POST['category'];
    $title = $_POST['title'];
    $author = $_POST['author'];
    $year = $_POST['year'];
    $description = $_POST['description'];

    // Get the category ID
    $stmt = $conn->prepare("SELECT id FROM categories WHERE name = ?");
    $stmt->bind_param("s", $category);
    $stmt->execute();
    $stmt->bind_result($category_id);
    $stmt->fetch();
    $stmt->close();

    if (!$category_id) {
        die("Category not found.");
    }

    // Insert book into the books table
    $stmt = $conn->prepare("INSERT INTO books (title, author, year, description) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssis", $title, $author, $year, $description);
    $stmt->execute();
    $book_id = $stmt->insert_id;
    $stmt->close();

    // Link book to category in category_books table
    $stmt = $conn->prepare("INSERT INTO category_books (book_id, category_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $book_id, $category_id);
    $stmt->execute();
    $stmt->close();

    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $imageName = basename($_FILES['image']['name']);
        $imageTmpName = $_FILES['image']['tmp_name'];
        $imagePath = "images/" . $imageName;

        if (!is_dir(__DIR__ . '/images')) {
            mkdir(__DIR__ . '/images', 0777, true);
        }

        if (move_uploaded_file($imageTmpName, __DIR__ . "/" . $imagePath)) {
            $stmt = $conn->prepare("INSERT INTO book_images (book_id, image_path) VALUES (?, ?)");
            $stmt->bind_param("is", $book_id, $imagePath);
            $stmt->execute();
            $stmt->close();
        }
    }

    echo "Book added successfully.";
}

$conn->close();
?>
